export enum AppState {
  DRAWING = 'DRAWING',
  GENERATING = 'GENERATING',
  RESULT = 'RESULT',
  EDITING = 'EDITING'
}

export interface GeneratedImage {
  data: string; // Base64 string
  mimeType: string;
}

export interface ToolConfig {
  brushSize: number;
  color: string;
  isEraser: boolean;
}