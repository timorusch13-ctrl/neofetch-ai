import React, { useState, useRef } from 'react';
import DrawingCanvas, { DrawingCanvasRef } from './components/DrawingCanvas';
import { PaintBrushIcon, EraserIcon, TrashIcon, SparklesIcon, ArrowPathIcon, CheckIcon } from './components/Icons';
import { generateImageFromSource } from './services/geminiService';
import { AppState, GeneratedImage, ToolConfig } from './types';

const App: React.FC = () => {
  const canvasRef = useRef<DrawingCanvasRef>(null);
  const [appState, setAppState] = useState<AppState>(AppState.DRAWING);
  const [toolConfig, setToolConfig] = useState<ToolConfig>({
    brushSize: 6, // Slightly thicker for better sketches
    color: '#a855f7', // Primary purple
    isEraser: false,
  });
  // Standard input set to 'realistic'
  const [prompt, setPrompt] = useState('realistic');
  const [generatedImage, setGeneratedImage] = useState<GeneratedImage | null>(null);
  const [sourceImageForEdit, setSourceImageForEdit] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
        setErrorMsg("Please enter a prompt.");
        setTimeout(() => setErrorMsg(null), 3000);
        return;
    }
    
    setAppState(AppState.GENERATING);
    setErrorMsg(null);

    try {
      let sourceData = "";
      
      if (sourceImageForEdit) {
        // We are editing an existing image
        sourceData = sourceImageForEdit;
      } else {
        // We are generating from sketch
        if (canvasRef.current) {
          sourceData = canvasRef.current.getCanvasData();
        }
      }

      if (!sourceData) throw new Error("No source image found");

      const result = await generateImageFromSource(sourceData, prompt);
      
      setGeneratedImage(result);
      setSourceImageForEdit(`data:${result.mimeType};base64,${result.data}`);
      setAppState(AppState.RESULT);
      setPrompt(''); // Clear prompt for editing steps
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Generation failed.");
      setAppState(sourceImageForEdit ? AppState.RESULT : AppState.DRAWING);
    }
  };

  const resetToDraw = () => {
    // If we have a generated image, load it onto the canvas so the user can "Re-edit" it
    if (generatedImage && canvasRef.current) {
        canvasRef.current.loadImage(`data:${generatedImage.mimeType};base64,${generatedImage.data}`);
    }

    setAppState(AppState.DRAWING);
    setGeneratedImage(null);
    setSourceImageForEdit(null);
    setPrompt('realistic'); // Reset to default prompt
  };

  const handleClearCanvas = () => {
    if (canvasRef.current) {
      canvasRef.current.clearCanvas();
    }
  };

  return (
    <div className="min-h-screen w-full bg-background text-white flex flex-col items-center justify-center p-4 sm:p-6 overflow-hidden relative select-none">
      
      {/* Header - Floating Pill */}
      <header className="absolute top-6 z-20">
        <div className="bg-surface/90 backdrop-blur-xl border border-white/10 px-8 py-3 rounded-full shadow-2xl shadow-purple-900/20">
          <h1 className="text-lg font-bold tracking-wider">
            NEON<span className="text-primary font-light">SKETCH</span>
          </h1>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="w-full max-w-5xl aspect-[4/5] md:aspect-[16/9] max-h-[80vh] flex flex-col md:flex-row gap-6 relative z-10">
        
        {/* Left Panel: Drawing Canvas */}
        {/* We use absolute positioning on mobile to hide it without destroying the component state or dimensions */}
        <div className={`
            flex-1 bg-secondary rounded-[3rem] border border-white/5 shadow-inner overflow-hidden relative transition-all duration-500 ease-in-out
            ${appState === AppState.RESULT ? 'absolute inset-0 z-[-1] opacity-0 pointer-events-none md:relative md:z-auto md:opacity-50 md:scale-95 md:grayscale md:block' : 'relative opacity-100 scale-100'}
        `}>
           <div className="absolute top-6 left-8 text-[10px] font-bold text-white/30 uppercase tracking-[0.2em] pointer-events-none z-10">
             Draw Here
           </div>
           <DrawingCanvas ref={canvasRef} toolConfig={toolConfig} className="w-full h-full" />
           
           {/* Canvas Tools - Floating Pill at Bottom of Canvas */}
           <div className={`absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-black/90 backdrop-blur-xl p-2 rounded-full border border-white/10 shadow-xl transition-all duration-300 ${appState !== AppState.DRAWING ? 'translate-y-20 opacity-0 pointer-events-none' : 'translate-y-0 opacity-100'}`}>
             <button 
                onClick={() => setToolConfig({...toolConfig, isEraser: false})}
                className={`p-4 rounded-full transition-all duration-300 ${!toolConfig.isEraser ? 'bg-primary text-white shadow-lg shadow-primary/40 scale-110' : 'text-white/50 hover:text-white hover:bg-white/10'}`}
             >
                <PaintBrushIcon className="w-6 h-6" />
             </button>
             <button 
                onClick={() => setToolConfig({...toolConfig, isEraser: true})}
                className={`p-4 rounded-full transition-all duration-300 ${toolConfig.isEraser ? 'bg-primary text-white shadow-lg shadow-primary/40 scale-110' : 'text-white/50 hover:text-white hover:bg-white/10'}`}
             >
                <EraserIcon className="w-6 h-6" />
             </button>
             <div className="w-px h-8 bg-white/10 mx-2"></div>
             <button 
                onClick={handleClearCanvas}
                className="p-4 rounded-full text-red-400 hover:bg-red-500/20 hover:text-red-400 transition-all"
             >
                <TrashIcon className="w-6 h-6" />
             </button>
           </div>
        </div>

        {/* Right Panel: Result / Output */}
        {(appState === AppState.RESULT || appState === AppState.GENERATING || appState === AppState.EDITING) && (
            <div className="flex-1 bg-black rounded-[3rem] border border-white/10 shadow-2xl overflow-hidden relative flex items-center justify-center group animate-in fade-in zoom-in duration-500">
                {appState === AppState.GENERATING ? (
                    <div className="flex flex-col items-center gap-6 p-8 text-center">
                        <div className="relative">
                            <div className="absolute inset-0 bg-primary blur-xl opacity-40 animate-pulse"></div>
                            <SparklesIcon className="w-16 h-16 text-primary relative z-10 animate-spin-slow" />
                        </div>
                        <p className="text-white/60 font-light text-lg tracking-widest animate-pulse">TRANSFORMING...</p>
                    </div>
                ) : generatedImage ? (
                    <>
                        <img 
                            src={`data:${generatedImage.mimeType};base64,${generatedImage.data}`} 
                            alt="Generated" 
                            className="w-full h-full object-contain"
                        />
                        {/* Result Actions */}
                        <div className="absolute top-6 right-6 flex gap-3">
                           <button 
                                onClick={resetToDraw}
                                className="bg-black/50 backdrop-blur-md p-3 rounded-full text-white/80 hover:text-white hover:bg-primary hover:scale-110 border border-white/10 transition-all duration-300 shadow-lg"
                                title="Re-edit on Canvas"
                           >
                               <ArrowPathIcon className="w-6 h-6" />
                           </button>
                        </div>
                         <div className="absolute top-6 left-8 text-[10px] font-bold text-white/50 uppercase tracking-[0.2em] drop-shadow-md pointer-events-none z-10">
                            AI Result
                        </div>
                    </>
                ) : null}
            </div>
        )}

      </main>

      {/* Bottom Bar: Prompt & Action */}
      <div className="fixed bottom-8 w-full max-w-xl px-6 z-30">
        <div className="relative group transition-all duration-300 focus-within:scale-105">
            {/* Glow effect */}
            <div className="absolute -inset-1 bg-gradient-to-r from-primary via-purple-500 to-blue-600 rounded-full blur opacity-30 group-hover:opacity-60 group-focus-within:opacity-80 transition duration-1000"></div>
            
            <div className="relative flex items-center p-1.5 bg-[#18181b] border border-white/10 rounded-full shadow-2xl">
                <input 
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    disabled={appState === AppState.GENERATING}
                    placeholder={appState === AppState.RESULT ? "Edit result (e.g. 'make it night')..." : "Describe creation..."}
                    className="flex-1 bg-transparent outline-none text-white placeholder-white/30 h-12 px-6 text-lg font-light"
                    onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                />
                <button 
                    onClick={handleGenerate}
                    disabled={appState === AppState.GENERATING}
                    className={`
                        h-12 px-8 rounded-full font-semibold text-sm tracking-wide transition-all flex items-center gap-2 shadow-lg
                        ${appState === AppState.GENERATING 
                            ? 'bg-white/10 text-white/20 cursor-not-allowed' 
                            : 'bg-white text-black hover:scale-105 hover:bg-primary hover:text-white'}
                    `}
                >
                    {appState === AppState.GENERATING ? '' : <SparklesIcon className="w-5 h-5" />}
                    {appState === AppState.GENERATING ? 'WAIT' : (appState === AppState.RESULT ? 'EDIT' : 'MAKE')}
                </button>
            </div>
        </div>
        
        {/* Error Toast */}
        {errorMsg && (
            <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-max bg-red-500/90 backdrop-blur text-white px-6 py-3 rounded-full text-sm font-medium shadow-xl animate-bounce">
                {errorMsg}
            </div>
        )}
      </div>

    </div>
  );
};

export default App;