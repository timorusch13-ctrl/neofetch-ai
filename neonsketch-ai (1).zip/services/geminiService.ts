import { GoogleGenAI } from "@google/genai";
import { GeneratedImage } from "../types";

// Initialize API client
// Note: Ensure process.env.API_KEY is set in your build environment or .env file
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates an image based on a source image (sketch or previous generation) and a prompt.
 */
export const generateImageFromSource = async (
  base64Source: string, 
  prompt: string
): Promise<GeneratedImage> => {
  try {
    // Using gemini-2.5-flash-image for fast image generation and editing capabilities
    const modelId = 'gemini-2.5-flash-image';
    
    // Strip header if present (e.g., "data:image/png;base64,")
    const cleanBase64 = base64Source.replace(/^data:image\/(png|jpeg|webp);base64,/, "");

    const response = await ai.models.generateContent({
      model: modelId,
      contents: {
        parts: [
          {
            text: prompt + " . Return a photorealistic, high quality image matching this description based on the input visual.",
          },
          {
            inlineData: {
              mimeType: 'image/png',
              data: cleanBase64,
            },
          },
        ],
      },
    });

    // Iterate through parts to find the image
    const parts = response.candidates?.[0]?.content?.parts;
    
    if (!parts) {
      throw new Error("No content returned from Gemini.");
    }

    for (const part of parts) {
      if (part.inlineData && part.inlineData.data) {
        return {
          data: part.inlineData.data,
          mimeType: part.inlineData.mimeType || 'image/png',
        };
      }
    }

    throw new Error("No image data found in the response.");

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};