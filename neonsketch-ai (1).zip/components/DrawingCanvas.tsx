import React, { useRef, useEffect, useState, useImperativeHandle, forwardRef } from 'react';
import { ToolConfig } from '../types';

interface DrawingCanvasProps {
  toolConfig: ToolConfig;
  className?: string;
}

export interface DrawingCanvasRef {
  getCanvasData: () => string;
  clearCanvas: () => void;
  loadImage: (base64Data: string) => void;
}

const DrawingCanvas = forwardRef<DrawingCanvasRef, DrawingCanvasProps>(({ toolConfig, className }, ref) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [context, setContext] = useState<CanvasRenderingContext2D | null>(null);

  // Initialize Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Initial setup
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    // Fill background with a dark color for "Neon" aesthetic, or white if preferred.
    // Since the prompt asks for dark app, let's do dark canvas with light ink.
    ctx.fillStyle = '#27272a'; // Zinc-800
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    setContext(ctx);
    
    // Handle resize
    const handleResize = () => {
        // Save current content
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = canvas.width;
        tempCanvas.height = canvas.height;
        tempCanvas.getContext('2d')?.drawImage(canvas, 0, 0);

        // Resize
        const parent = canvas.parentElement;
        if (parent) {
            canvas.width = parent.clientWidth;
            canvas.height = parent.clientHeight;
        }

        // Restore config
        if(ctx) {
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.fillStyle = '#27272a';
            // We don't necessarily want to clear here if we are about to restore, 
            // but we need a background if the image doesn't cover everything.
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(tempCanvas, 0, 0, tempCanvas.width, tempCanvas.height); // This might stretch, but it keeps data
        }
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Update Brush Settings
  useEffect(() => {
    if (!context) return;
    context.lineWidth = toolConfig.brushSize;
    context.strokeStyle = toolConfig.isEraser ? '#27272a' : toolConfig.color;
  }, [toolConfig, context]);

  useImperativeHandle(ref, () => ({
    getCanvasData: () => {
      if (canvasRef.current) {
        return canvasRef.current.toDataURL('image/png');
      }
      return '';
    },
    clearCanvas: () => {
      if (canvasRef.current && context) {
        context.fillStyle = '#27272a';
        context.fillRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      }
    },
    loadImage: (base64Data: string) => {
        const img = new Image();
        img.onload = () => {
            if (canvasRef.current && context) {
                // Draw the image to fit the canvas
                context.drawImage(img, 0, 0, canvasRef.current.width, canvasRef.current.height);
            }
        };
        img.src = base64Data;
    }
  }));

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDrawing(true);
    if (!context || !canvasRef.current) return;

    const { offsetX, offsetY } = getCoordinates(e);
    context.beginPath();
    context.moveTo(offsetX, offsetY);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !context || !canvasRef.current) return;
    e.preventDefault(); // Prevent scrolling on touch

    const { offsetX, offsetY } = getCoordinates(e);
    context.lineTo(offsetX, offsetY);
    context.stroke();
  };

  const stopDrawing = () => {
    if (!isDrawing || !context) return;
    context.closePath();
    setIsDrawing(false);
  };

  const getCoordinates = (e: React.MouseEvent | React.TouchEvent) => {
    if (!canvasRef.current) return { offsetX: 0, offsetY: 0 };

    let clientX, clientY;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }

    const rect = canvasRef.current.getBoundingClientRect();
    return {
      offsetX: clientX - rect.left,
      offsetY: clientY - rect.top
    };
  };

  return (
    <canvas
      ref={canvasRef}
      className={`touch-none w-full h-full cursor-crosshair ${className}`}
      onMouseDown={startDrawing}
      onMouseMove={draw}
      onMouseUp={stopDrawing}
      onMouseLeave={stopDrawing}
      onTouchStart={startDrawing}
      onTouchMove={draw}
      onTouchEnd={stopDrawing}
    />
  );
});

DrawingCanvas.displayName = 'DrawingCanvas';
export default DrawingCanvas;